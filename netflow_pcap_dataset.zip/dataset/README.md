# Dataset NetFlow + PCAP (sintetis) untuk forensik jaringan

**Status data: SINTETIS.** Seluruh isi paket ini dibangkitkan/dihitung dari `netflow.csv`
dengan skrip di `scripts/` (seed tetap `20261002`). Tidak ada bagian yang berasal dari
capture testbed. Bila dipakai di naskah, sebutkan sebagai data simulasi.

## Isi

| # | Folder | File utama | Isi |
|---|---|---|---|
| 1 | `1_netflow/` | `netflow.csv` | File asli (5.395 flow, tidak diubah) |
|   |             | `netflow_enriched.csv` | + timestamp flow, nama PCAP, hitungan TCP flag (SYN/ACK/RST/FIN/PSH, OR-flags), TTL min/max/mean, hitungan ARP request/reply, MAC |
| 2 | `2_pcap/` | 20 file `*.pcap` | Satu file per skenario × repetisi; 699.600 paket, ±135 MB |
|   |           | `pcap_manifest.csv` | Skenario, durasi capture, onset serangan, jumlah paket, SHA-256 |
|   |           | `packet_ground_truth.csv.gz` | Label per paket: file, nomor paket, timestamp, flow_id, label |
|   |           | `flows_reextracted_from_pcap.csv`, `verification_report.txt` | Hasil agregasi ulang PCAP dan perbandingannya dengan `netflow.csv` |
| 3 | `3_predictions/` | `predictions_repeated_cv.csv` | y_true, y_pred, probabilitas 4 kelas; 5×5-fold (26.975 baris) |
|   |                  | `predictions_loro.csv` | Sama, skema leave-one-repetition-out (5.395 baris) |
| 4 | `4_fold_results/` | `fold_metrics.csv` | Accuracy, precision, recall, F1 (macro & weighted), AUC OvR per fold; 25 + 5 baris |
|   |                   | `per_class_fold_metrics.csv`, `confusion_matrix_per_fold.csv`, `summary_mean_std.csv` | Per kelas, confusion matrix, mean ± std + CI 95% |
|   |                   | `feature_importance.csv`, `feature_ablation.csv` | Diagnostik fitur |
| 5 | `5_timing/` | `timing_correlation_log.csv` | Satu baris per alert (4.155): attack start, alert time, retrieval time, correlation time |
|   |             | `capture_timing_summary.csv`, `scenario_timing_summary.csv` | Ringkasan per capture dan per skenario |

Label: 0 = Benign, 1 = Port_Scanning, 2 = DDoS_SYN_Flood, 3 = ARP_Spoofing.

## Cara PCAP dibangun

Tiap flow record diekspansi menjadi paket sehingga agregasi ulang PCAP menghasilkan angka
yang sama dengan `netflow.csv`.

- Flow unidirectional (model NetFlow v5): semua paket berarah src → dst. Tidak ada paket balasan
  (SYN-ACK, RST dari target, echo reply).
- `bytes` = jumlah IP total length untuk TCP/UDP/ICMP; jumlah panjang frame untuk ARP.
- Jumlah SYN = `round(tcp_syn_ratio × packets)`. Sisa paket: RST (port scan), ACK (SYN flood),
  PSH-ACK/ACK lalu FIN-ACK (benign).
- ARP spoofing: request sah dari pemilik IP (MAC `02:00:c0:a8:01:xx`), reply palsu dari satu MAC
  penyerang per capture (`02:aa:aa:aa:00:0<rep>`) yang mengklaim IP tersebut. Akibatnya satu IP
  terlihat dengan dua MAC, dan itu yang dipakai sebagai signature korelasi.
- TTL: 64/128 untuk host benign (ditentukan dari IP), acak 37–59 untuk port scan (kebiasaan nmap),
  64 untuk SYN flood (default hping3). Ini asumsi, bukan hasil ukur.
- Timestamp resolusi nanodetik. Titik nol `1700000000` adalah epoch sintetis, bukan tanggal eksperimen.
  Serangan dimulai 3–10 detik setelah capture dimulai (`attack_onset_rel_s`).
- Payload adalah filler bertanda `SYNTHETIC-TRAFFIC-PAYLOAD-`, bukan protokol aplikasi yang valid
  (Wireshark akan menandai DNS/NTP/TLS sebagai malformed).
- Checksum IP/TCP/UDP/ICMP valid.

Hasil verifikasi (scapy): 5.395/5.395 flow cocok; selisih paket 0, selisih byte 0, selisih durasi 0.

## Cara prediksi dan metrik dihitung

Random Forest (200 pohon, hyperparameter default scikit-learn 1.9.1) pada 13 fitur:
`src_port, dst_port, duration_s, packets, bytes, mean_packet_size_B, packets_per_second,
tcp_syn_ratio, arp_request_reply_ratio` + one-hot protokol. Tidak dipakai: IP, `flow_id`,
`scenario`, `repetition`, dan `capture_duration_s` (nilainya 1:1 dengan label).

Semua angka adalah keluaran model yang benar-benar dijalankan.

## Cara timing diukur

Dua jenis waktu, jangan dicampur saat melaporkan:

- **Timeline sintetis**: `attack_start`, `flow_start`, `flow_end` berasal dari PCAP sintetis.
- **Terukur (wall-clock)**: `inference_time_ms`, `retrieval_time_ms`, `correlation_time_ms`
  diukur saat skrip dijalankan (2 vCPU, Linux, Python 3.13; lihat `environment.txt`).

`alert_time = flow_end + inference_time`. Exporter timeout (active/inactive) tidak dimodelkan,
jadi `detection_delay_s` praktis sama dengan durasi flow. Retrieval adalah pemindaian
sekuensial PCAP tanpa indeks, sehingga waktunya sebanding dengan ukuran file.

## Keterbatasan yang perlu diketahui

1. **Kelas terpisah sempurna.** Semua fold menghasilkan accuracy/F1/AUC = 1,000 dengan std 0.
   Kolom `packets` saja sudah cukup (Port scan 10–11, Benign 128–129, ARP 130–131, DDoS 2314–2315).
   Lihat `feature_ablation.csv`. Angka ini mencerminkan cara `netflow.csv` dibangkitkan, bukan
   kemampuan model di jaringan nyata.
2. **Keanehan di `netflow.csv`** yang dibiarkan apa adanya: flow ICMP punya port (di PCAP
   `src_port` dipakai sebagai ICMP id, `dst_port` tidak terwakili); flow UDP/ICMP benign punya
   `tcp_syn_ratio` > 0 (tidak bisa diwujudkan di paket); kolom `data_status` kosong; tiap flow
   benign berisi 128–129 paket; IP sumber serangan tersebar di ±240 host.
3. `netflow.csv` tidak memuat TCP flags dan TTL secara eksplisit. Kolom itu ada di
   `netflow_enriched.csv` dan diturunkan dari PCAP sintetis.
4. Rasio SYN dan ARP di PCAP berbeda sedikit dari `netflow.csv` karena pembulatan ke jumlah paket
   bulat (maks 0,05 untuk SYN, 0,015 untuk ARP).
5. Pembanding Zeek/Suricata/Snort tidak dijalankan.

## Reproduksi

```
pip install numpy pandas scikit-learn scapy
python scripts/01_generate_pcap.py        # PCAP + netflow_enriched.csv
python scripts/02_verify_pcap.py          # verifikasi PCAP vs NetFlow
python scripts/03_train_eval.py           # prediksi + metrik per fold
python scripts/04_timing_correlation.py   # log timing/korelasi
```

Langkah 1–3 deterministik. Langkah 4 menghasilkan waktu terukur yang berbeda di tiap mesin.
