#!/usr/bin/env python3
"""
02_verify_pcap.py
Verifikasi independen: PCAP dibaca ulang dengan scapy, diagregasi per flow langsung dari
byte paket (tanpa memakai indeks ground-truth), lalu dibandingkan dengan netflow.csv.
Juga memeriksa checksum IP/TCP/UDP/ICMP lewat dissector scapy pada sampel paket.
Output: 2_pcap/flows_reextracted_from_pcap.csv dan 2_pcap/verification_report.txt
"""
import os, struct, socket, glob
from collections import defaultdict
import pandas as pd
from scapy.all import RawPcapNgReader, RawPcapReader, Ether, IP, TCP, UDP, ICMP

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, "2_pcap")
nf = pd.read_csv(os.path.join(ROOT, "1_netflow", "netflow.csv"))
man = pd.read_csv(os.path.join(P, "pcap_manifest.csv")).set_index("pcap_file")
PROTO = {6: "TCP", 17: "UDP", 1: "ICMP"}
rows, lines, bad_ck, ck_n = [], [], 0, 0


def ts_ns(meta):
    # RawPcapReader pada file nanodetik: (sec, nsec, wirelen, caplen)
    return meta.sec * 10**9 + meta.usec


for path in sorted(glob.glob(os.path.join(P, "*.pcap"))):
    fn = os.path.basename(path)
    agg = defaultdict(lambda: [0, 0, None, None, 0, 0, 0, set()])   # pk, bytes, first, last, syn, req, rep, ttl
    rd = RawPcapReader(path)
    assert rd.nano, "PCAP harus beresolusi nanodetik"
    n = 0
    for raw, meta in rd:
        n += 1
        t = ts_ns(meta)
        et = raw[12:14]
        if et == b"\x08\x06":
            op = struct.unpack("!H", raw[20:22])[0]
            key = (socket.inet_ntoa(raw[28:32]), socket.inet_ntoa(raw[38:42]), "ARP", 0, 0)
            a = agg[key]; a[1] += len(raw); a[5] += op == 1; a[6] += op == 2
        else:
            ihl = (raw[14] & 0x0F) * 4
            tot = struct.unpack("!H", raw[16:18])[0]
            pr = raw[23]
            src, dst = socket.inet_ntoa(raw[26:30]), socket.inet_ntoa(raw[30:34])
            l4 = 14 + ihl
            if pr == 1:
                sp, dp = struct.unpack("!H", raw[l4 + 4:l4 + 6])[0], -1     # ICMP id; tidak ada dst port
            else:
                sp, dp = struct.unpack("!HH", raw[l4:l4 + 4])
            key = (src, dst, PROTO[pr], sp, dp)
            a = agg[key]; a[1] += tot; a[7].add(raw[22])
            if pr == 6:
                a[4] += bool(raw[l4 + 13] & 0x02)
            if ck_n < 40000 and n % 7 == 0:      # sampel untuk cek checksum via dissector scapy
                ck_n += 1
                pkt = Ether(raw)
                orig = (pkt[IP].chksum, pkt[IP].payload.chksum)
                del pkt[IP].chksum
                del pkt[IP].payload.chksum
                re = Ether(bytes(pkt))
                if orig != (re[IP].chksum, re[IP].payload.chksum):
                    bad_ck += 1
        a[0] += 1
        a[2] = t if a[2] is None else min(a[2], t)
        a[3] = t if a[3] is None else max(a[3], t)
    rd.close()
    m = man.loc[fn]
    for (src, dst, pr, sp, dp), a in agg.items():
        rows.append(dict(pcap_file=fn, scenario=m.scenario, repetition=m.repetition, src_ip=src, dst_ip=dst,
                         protocol=pr, src_port=sp, dst_port=dp, packets=a[0], bytes=a[1],
                         duration_s=round((a[3] - a[2]) / 1e9, 6), first_ts_ns=a[2], last_ts_ns=a[3],
                         tcp_syn_count=a[4], arp_request_count=a[5], arp_reply_count=a[6],
                         ttl_min=min(a[7]) if a[7] else None, ttl_max=max(a[7]) if a[7] else None))
    lines.append(f"{fn}: packets={n} (manifest {m.packets}) flows={len(agg)} (manifest {m.flows})")
    assert n == m.packets and len(agg) == m.flows

rx = pd.DataFrame(rows)
# ICMP: dst_port pada netflow.csv tidak bisa direpresentasikan di paket -> cocokkan tanpa dst_port
a = nf.copy(); b = rx.copy()
a.loc[a.protocol == "ICMP", "dst_port"] = -1
key = ["scenario", "repetition", "src_ip", "dst_ip", "protocol", "src_port", "dst_port"]
j = a.merge(b, on=key, how="outer", suffixes=("_nf", "_pcap"), indicator=True)
rx = rx.merge(a[key + ["flow_id"]], on=key, how="left")
rx.insert(0, "flow_id", rx.pop("flow_id"))
rx.sort_values("flow_id").to_csv(os.path.join(P, "flows_reextracted_from_pcap.csv"), index=False)

both = j[j._merge == "both"]
rep = [
    "VERIFIKASI PCAP vs netflow.csv (parser: scapy RawPcapReader + dissector scapy)",
    *lines, "",
    f"flow di netflow.csv            : {len(nf)}",
    f"flow hasil re-ekstraksi PCAP   : {len(rx)}",
    f"flow cocok (5-tuple)           : {len(both)}",
    f"hanya di netflow / hanya di PCAP: {(j._merge == 'left_only').sum()} / {(j._merge == 'right_only').sum()}",
    f"selisih jumlah paket != 0      : {(both.packets_nf != both.packets_pcap).sum()}",
    f"selisih jumlah byte  != 0      : {(both.bytes_nf != both.bytes_pcap).sum()}",
    f"selisih durasi maks (s)        : {(both.duration_s_nf - both.duration_s_pcap).abs().max():.9f}",
    f"total paket / byte (PCAP)      : {rx.packets.sum()} / {rx.bytes.sum()}",
    f"total paket / byte (netflow)   : {nf.packets.sum()} / {nf.bytes.sum()}",
    f"checksum diperiksa (sampel)    : {ck_n}, tidak valid: {bad_ck}",
]
tcp = both[both.protocol == "TCP"]
d = (tcp.tcp_syn_count / tcp.packets_pcap - tcp.tcp_syn_ratio).abs()
rep.append(f"|SYN ratio PCAP - netflow| TCP : mean {d.mean():.4f}, max {d.max():.4f} (pembulatan ke jumlah paket bulat)")
arp = both[both.protocol == "ARP"]
d = (arp.arp_request_count / arp.arp_reply_count - arp.arp_request_reply_ratio).abs()
rep.append(f"|ARP req/reply PCAP - netflow| : mean {d.mean():.4f}, max {d.max():.4f}")
open(os.path.join(P, "verification_report.txt"), "w").write("\n".join(rep) + "\n")
print("\n".join(rep))
