#!/usr/bin/env python3
"""
04_timing_correlation.py
Menjalankan pipeline deteksi -> retrieval -> korelasi dan mencatat waktunya.

Untuk tiap repetisi capture (model dilatih pada 4 repetisi lain / leave-one-repetition-out):
  1. Flow "diekspor" berurutan menurut waktu berakhirnya flow (timeline sintetis PCAP).
  2. Tiap flow diklasifikasi satu per satu; latensi inferensi DIUKUR (wall-clock).
  3. Bila y_pred != Benign -> alert. alert_time = flow_end + latensi inferensi terukur.
  4. Retrieval: PCAP capture tsb dipindai sekuensial, paket yang cocok 5-tuple + jendela
     waktu flow diambil. Waktu retrieval DIUKUR.
  5. Korelasi: paket hasil retrieval dicocokkan dengan flow record (paket, byte, durasi)
     dan diperiksa signature tingkat paket (rasio SYN; konflik IP-MAC untuk ARP).
     Waktu korelasi DIUKUR.

Dua jenis waktu dalam log ini:
  - timeline sintetis : attack_start, flow_start/end (berasal dari PCAP sintetis)
  - terukur wall-clock: inference/retrieval/correlation (di mesin tempat skrip ini dijalankan)
Tidak ada exporter timeout (active/inactive) yang dimodelkan: flow dianggap diekspor saat berakhir.
"""
import os, time, mmap, struct, socket, platform
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "5_timing"); os.makedirs(OUT, exist_ok=True)
SEED = 20261002
NUM = ["src_port", "dst_port", "duration_s", "packets", "bytes", "mean_packet_size_B",
       "packets_per_second", "tcp_syn_ratio", "arp_request_reply_ratio"]
PROTOS = ["TCP", "UDP", "ICMP", "ARP"]
PNUM = {"TCP": 6, "UDP": 17, "ICMP": 1}

df = pd.read_csv(os.path.join(ROOT, "1_netflow", "netflow_enriched.csv"))
X = df[NUM].copy()
for p in PROTOS:
    X["proto_" + p] = (df.protocol == p).astype(int)
y = df.label.to_numpy()


def retrieve(path, r):
    """Pindai PCAP sekuensial; kembalikan list (ts_ns, frame) yang cocok dengan flow r."""
    t0, t1 = int(r.flow_start_epoch_ns), int(r.flow_end_epoch_ns)
    src, dst = socket.inet_aton(r.src_ip), socket.inet_aton(r.dst_ip)
    out = []
    with open(path, "rb") as fh:
        mm = mmap.mmap(fh.fileno(), 0, access=mmap.ACCESS_READ)
        n, off = len(mm), 24
        unpack = struct.Struct("<IIII").unpack_from
        if r.protocol == "ARP":
            while off < n:
                s, ns, cl, _ = unpack(mm, off); off += 16
                t = s * 1_000_000_000 + ns
                if t0 <= t <= t1 and mm[off + 12:off + 14] == b"\x08\x06" \
                        and mm[off + 28:off + 32] == src and mm[off + 38:off + 42] == dst:
                    out.append((t, mm[off:off + cl]))
                off += cl
        else:
            pn = PNUM[r.protocol]
            if r.protocol == "ICMP":
                l4 = struct.pack("!H", int(r.src_port)); a, b = 38, 40      # ICMP id
            else:
                l4 = struct.pack("!HH", int(r.src_port), int(r.dst_port)); a, b = 34, 38
            while off < n:
                s, ns, cl, _ = unpack(mm, off); off += 16
                t = s * 1_000_000_000 + ns
                if t0 <= t <= t1 and mm[off + 23] == pn and mm[off + 26:off + 30] == src \
                        and mm[off + 30:off + 34] == dst and mm[off + a:off + b] == l4:
                    out.append((t, mm[off:off + cl]))
                off += cl
        mm.close()
    return out


def correlate(pk, r):
    """Cocokkan paket hasil retrieval dengan flow record + signature tingkat paket."""
    n = len(pk)
    if n == 0:
        return dict(packets_retrieved=0, bytes_retrieved=0, pcap_duration_s=np.nan, flow_pcap_match=0,
                    pcap_syn_ratio=np.nan, pcap_distinct_mac_for_src_ip=np.nan, signature_confirmed=0)
    dur = (pk[-1][0] - pk[0][0]) / 1e9
    syn_ratio, nmac = np.nan, np.nan
    if r.protocol == "ARP":
        nbytes = sum(len(f) for _, f in pk)
        macs = {f[22:28] for _, f in pk}                 # sender hardware address utk sender IP yg sama
        nmac = len(macs)
        sig = nmac > 1                                   # satu IP diklaim >1 MAC = indikasi ARP spoofing
    else:
        nbytes = sum(struct.unpack_from("!H", f, 16)[0] for _, f in pk)
        if r.protocol == "TCP":
            ihl = (pk[0][1][14] & 0x0F) * 4
            syn_ratio = sum(bool(f[14 + ihl + 13] & 0x02) for _, f in pk) / n
            sig = syn_ratio >= 0.5                       # dominasi SYN = scan / SYN flood
        else:
            sig = False
    match = (n == int(r.packets)) and (nbytes == int(r.bytes)) and abs(dur - float(r.duration_s)) < 1e-6
    return dict(packets_retrieved=n, bytes_retrieved=nbytes, pcap_duration_s=round(dur, 9),
                flow_pcap_match=int(match), pcap_syn_ratio=syn_ratio,
                pcap_distinct_mac_for_src_ip=nmac, signature_confirmed=int(bool(sig)))


rows, summ = [], []
for rep in sorted(df.repetition.unique()):
    tr = (df.repetition != rep).to_numpy()
    rf = RandomForestClassifier(n_estimators=200, random_state=SEED + 1000 + int(rep), n_jobs=1)
    rf.fit(X[tr], y[tr])
    rf.predict(X.iloc[[0]])                              # warm-up
    for cap_id, g in df[df.repetition == rep].groupby("capture_id", sort=False):
        g = g.sort_values("flow_end_epoch_ns")
        path = os.path.join(ROOT, "2_pcap", g.pcap_file.iloc[0])
        is_attack = g.label.iloc[0] != 0
        attack_start = int(g.flow_start_epoch_ns.min()) if is_attack else None
        cap_rows = []
        for r in g.itertuples(index=False):
            xi = X.loc[[df.index[df.flow_id == r.flow_id][0]]]
            t = time.perf_counter(); yp = int(rf.predict(xi)[0]); t_inf = time.perf_counter() - t
            if yp == 0:
                continue
            t = time.perf_counter(); pk = retrieve(path, r); t_ret = time.perf_counter() - t
            t = time.perf_counter(); c = correlate(pk, r); t_cor = time.perf_counter() - t
            alert_ns = int(r.flow_end_epoch_ns) + int(t_inf * 1e9)
            cap_rows.append(dict(
                capture_id=cap_id, pcap_file=r.pcap_file, scenario=r.scenario, repetition=int(rep),
                flow_id=int(r.flow_id), y_true=int(r.label), y_pred=yp,
                attack_start_epoch_ns=attack_start,
                flow_start_epoch_ns=int(r.flow_start_epoch_ns), flow_end_epoch_ns=int(r.flow_end_epoch_ns),
                alert_time_epoch_ns=alert_ns,
                attack_start_rel_s=(None if attack_start is None else round((attack_start - r.capture_start_epoch_s * 10**9) / 1e9, 9)),
                alert_time_rel_s=round((alert_ns - r.capture_start_epoch_s * 10**9) / 1e9, 9),
                detection_delay_s=round((alert_ns - int(r.flow_start_epoch_ns)) / 1e9, 9),
                time_since_attack_start_s=(None if attack_start is None else round((alert_ns - attack_start) / 1e9, 9)),
                inference_time_ms=round(t_inf * 1e3, 4), retrieval_time_ms=round(t_ret * 1e3, 4),
                correlation_time_ms=round(t_cor * 1e3, 4),
                total_response_ms=round((t_inf + t_ret + t_cor) * 1e3, 4), **c))
        rows.extend(cap_rows)
        c = pd.DataFrame(cap_rows)
        base = dict(capture_id=cap_id, pcap_file=g.pcap_file.iloc[0], scenario=g.scenario.iloc[0], repetition=int(rep),
                    capture_start_epoch_s=int(g.capture_start_epoch_s.iloc[0]),
                    capture_duration_s=int(g.capture_duration_s.iloc[0]),
                    pcap_packets=int(g.packets.sum()), pcap_size_mb=round(os.path.getsize(path) / 1e6, 3),
                    n_flows=len(g), n_attack_flows=int((g.label != 0).sum()), n_alerts=len(c))
        if len(c):
            first = c.sort_values("alert_time_epoch_ns").iloc[0]
            base.update(
                attack_start_rel_s=first.attack_start_rel_s, first_alert_rel_s=first.alert_time_rel_s,
                time_to_first_alert_s=first.time_since_attack_start_s,
                detection_delay_mean_s=c.detection_delay_s.mean(), detection_delay_max_s=c.detection_delay_s.max(),
                inference_ms_mean=c.inference_time_ms.mean(), inference_ms_p95=c.inference_time_ms.quantile(.95),
                retrieval_ms_mean=c.retrieval_time_ms.mean(), retrieval_ms_median=c.retrieval_time_ms.median(),
                retrieval_ms_p95=c.retrieval_time_ms.quantile(.95),
                correlation_ms_mean=c.correlation_time_ms.mean(), correlation_ms_median=c.correlation_time_ms.median(),
                correlation_ms_p95=c.correlation_time_ms.quantile(.95),
                total_response_ms_mean=c.total_response_ms.mean(),
                flow_pcap_match_rate=c.flow_pcap_match.mean(), signature_confirmed_rate=c.signature_confirmed.mean())
        summ.append(base)
        print(cap_id, "alerts", len(c), "" if not len(c) else
              f"ret {c.retrieval_time_ms.mean():.2f} ms  cor {c.correlation_time_ms.mean():.3f} ms  match {c.flow_pcap_match.mean():.3f}")

log = pd.DataFrame(rows)
log["data_status"] = "synthetic_timeline+measured_latency"
log.to_csv(os.path.join(OUT, "timing_correlation_log.csv"), index=False)
s = pd.DataFrame(summ)
s.to_csv(os.path.join(OUT, "capture_timing_summary.csv"), index=False, float_format="%.6f")
agg = log.groupby("scenario").agg(
    n_alerts=("flow_id", "size"),
    detection_delay_s_mean=("detection_delay_s", "mean"), detection_delay_s_std=("detection_delay_s", "std"),
    inference_ms_mean=("inference_time_ms", "mean"), inference_ms_std=("inference_time_ms", "std"),
    retrieval_ms_mean=("retrieval_time_ms", "mean"), retrieval_ms_std=("retrieval_time_ms", "std"),
    correlation_ms_mean=("correlation_time_ms", "mean"), correlation_ms_std=("correlation_time_ms", "std"),
    total_response_ms_mean=("total_response_ms", "mean"),
    flow_pcap_match_rate=("flow_pcap_match", "mean"), signature_confirmed_rate=("signature_confirmed", "mean")).reset_index()
agg.to_csv(os.path.join(OUT, "scenario_timing_summary.csv"), index=False, float_format="%.6f")
print(agg.to_string())
open(os.path.join(OUT, "environment.txt"), "w").write(
    f"platform {platform.platform()}\npython {platform.python_version()}\ncpu_count {os.cpu_count()}\n"
    "retrieval: pemindaian sekuensial PCAP (mmap, Python murni, tanpa indeks)\n"
    "inference: RandomForest 200 pohon, n_jobs=1, satu flow per panggilan\n")
