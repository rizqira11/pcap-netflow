#!/usr/bin/env python3
"""
03_train_eval.py
Melatih Random Forest pada fitur NetFlow dan menyimpan:
  3_predictions/  y_true, y_pred, probabilitas tiap kelas (out-of-fold) per flow
  4_fold_results/ metrik per fold/repetisi, per kelas, confusion matrix, ringkasan, ablation

Dua skema evaluasi:
  A. repeated_stratified_5x5 : 5 repetisi x 5-fold stratified CV (25 fold)
  B. leave_one_repetition_out: dilatih pada 4 repetisi capture, diuji pada 1 repetisi (5 fold)

Kolom yang TIDAK dipakai sebagai fitur: flow_id, scenario, repetition, src_ip, dst_ip,
capture_duration_s (nilainya 1:1 dengan label -> bocoran label), data_status.
Semua angka di sini adalah hasil komputasi nyata atas netflow.csv, bukan nilai yang diisi manual.
"""
import os, time, platform
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support, roc_auc_score,
                             confusion_matrix, balanced_accuracy_score)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
D3, D4 = os.path.join(ROOT, "3_predictions"), os.path.join(ROOT, "4_fold_results")
os.makedirs(D3, exist_ok=True); os.makedirs(D4, exist_ok=True)
SEED = 20261002
CLASSES = [0, 1, 2, 3]
NAMES = {0: "Benign", 1: "Port_Scanning", 2: "DDoS_SYN_Flood", 3: "ARP_Spoofing"}
NUM = ["src_port", "dst_port", "duration_s", "packets", "bytes", "mean_packet_size_B",
       "packets_per_second", "tcp_syn_ratio", "arp_request_reply_ratio"]
PROTOS = ["TCP", "UDP", "ICMP", "ARP"]

df = pd.read_csv(os.path.join(ROOT, "1_netflow", "netflow.csv"))


def features(d, cols=None):
    X = d[NUM].copy()
    for p in PROTOS:
        X["proto_" + p] = (d.protocol == p).astype(int)
    return X if cols is None else X[cols]


X_all, y = features(df), df.label.to_numpy()
FEATS = list(X_all.columns)


def splits(scheme):
    if scheme == "repeated_stratified_5x5":
        for rep in range(1, 6):
            skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED + rep)
            for fold, (tr, te) in enumerate(skf.split(X_all, y), 1):
                yield rep, fold, tr, te, SEED + 100 * rep + fold
    else:
        for fold in sorted(df.repetition.unique()):
            te = np.flatnonzero(df.repetition.to_numpy() == fold)
            tr = np.flatnonzero(df.repetition.to_numpy() != fold)
            yield 1, int(fold), tr, te, SEED + 1000 + int(fold)


def evaluate(scheme, cols=None, save=True):
    X = X_all if cols is None else X_all[cols]
    preds, folds, percls, cms, imps = [], [], [], [], []
    for rep, fold, tr, te, rs in splits(scheme):
        rf = RandomForestClassifier(n_estimators=200, random_state=rs, n_jobs=-1)
        t0 = time.perf_counter(); rf.fit(X.iloc[tr], y[tr]); t_fit = time.perf_counter() - t0
        t0 = time.perf_counter(); proba = rf.predict_proba(X.iloc[te]); t_inf = time.perf_counter() - t0
        yp = rf.classes_[proba.argmax(1)]
        yt = y[te]
        pm, rm, fm, _ = precision_recall_fscore_support(yt, yp, labels=CLASSES, average="macro", zero_division=0)
        pw, rw, fw, _ = precision_recall_fscore_support(yt, yp, labels=CLASSES, average="weighted", zero_division=0)
        pc, rc, fc, sc = precision_recall_fscore_support(yt, yp, labels=CLASSES, zero_division=0)
        folds.append(dict(scheme=scheme, repetition=rep, fold=fold, n_train=len(tr), n_test=len(te),
                          accuracy=accuracy_score(yt, yp), balanced_accuracy=balanced_accuracy_score(yt, yp),
                          precision_macro=pm, recall_macro=rm, f1_macro=fm,
                          precision_weighted=pw, recall_weighted=rw, f1_weighted=fw,
                          auc_ovr_macro=roc_auc_score(yt, proba, multi_class="ovr", average="macro", labels=CLASSES),
                          auc_ovr_weighted=roc_auc_score(yt, proba, multi_class="ovr", average="weighted", labels=CLASSES),
                          n_errors=int((yt != yp).sum()),
                          train_time_s=t_fit, inference_time_s=t_inf, inference_ms_per_flow=1e3 * t_inf / len(te)))
        for i, c in enumerate(CLASSES):
            percls.append(dict(scheme=scheme, repetition=rep, fold=fold, label=c, class_name=NAMES[c],
                               precision=pc[i], recall=rc[i], f1=fc[i], support=int(sc[i]),
                               auc_ovr=roc_auc_score((yt == c).astype(int), proba[:, i])))
        cm = confusion_matrix(yt, yp, labels=CLASSES)
        for i in CLASSES:
            for j in CLASSES:
                cms.append(dict(scheme=scheme, repetition=rep, fold=fold, y_true=i, y_pred=j, count=int(cm[i, j])))
        imps.append(pd.Series(rf.feature_importances_, index=X.columns))
        p = pd.DataFrame(dict(scheme=scheme, repetition=rep, fold=fold, flow_id=df.flow_id.to_numpy()[te],
                              scenario=df.scenario.to_numpy()[te], capture_repetition=df.repetition.to_numpy()[te],
                              y_true=yt, y_pred=yp))
        for i, c in enumerate(CLASSES):
            p[f"prob_{c}_{NAMES[c]}"] = proba[:, i]
        p["correct"] = (yt == yp).astype(int)
        preds.append(p)
    return (pd.concat(preds, ignore_index=True), pd.DataFrame(folds), pd.DataFrame(percls),
            pd.DataFrame(cms), pd.concat(imps, axis=1))


METRICS = ["accuracy", "balanced_accuracy", "precision_macro", "recall_macro", "f1_macro",
           "precision_weighted", "recall_weighted", "f1_weighted", "auc_ovr_macro", "auc_ovr_weighted"]
allf, allc, allm, summ, imp_rows = [], [], [], [], []
for scheme, tag in [("repeated_stratified_5x5", "repeated_cv"), ("leave_one_repetition_out", "loro")]:
    p, f, c, m, imp = evaluate(scheme)
    p.sort_values(["repetition", "fold", "flow_id"]).to_csv(os.path.join(D3, f"predictions_{tag}.csv"),
                                                              index=False, float_format="%.6f")
    allf.append(f); allc.append(c); allm.append(m)
    for k in METRICS:
        v = f[k].to_numpy(); n = len(v); sd = v.std(ddof=1)
        summ.append(dict(scheme=scheme, metric=k, n_folds=n, mean=v.mean(), std=sd, min=v.min(), max=v.max(),
                         ci95_low=v.mean() - 1.96 * sd / np.sqrt(n), ci95_high=v.mean() + 1.96 * sd / np.sqrt(n)))
    for feat in imp.index:
        imp_rows.append(dict(scheme=scheme, feature=feat, importance_mean=imp.loc[feat].mean(),
                             importance_std=imp.loc[feat].std(ddof=1)))
    print(scheme, f[["accuracy", "f1_macro", "auc_ovr_macro", "n_errors"]].describe().loc[["mean", "std", "min"]].to_string())

pd.concat(allf).to_csv(os.path.join(D4, "fold_metrics.csv"), index=False, float_format="%.6f")
pd.concat(allc).to_csv(os.path.join(D4, "per_class_fold_metrics.csv"), index=False, float_format="%.6f")
pd.concat(allm).to_csv(os.path.join(D4, "confusion_matrix_per_fold.csv"), index=False)
pd.DataFrame(summ).to_csv(os.path.join(D4, "summary_mean_std.csv"), index=False, float_format="%.6f")
pd.DataFrame(imp_rows).sort_values(["scheme", "importance_mean"], ascending=[True, False]).to_csv(
    os.path.join(D4, "feature_importance.csv"), index=False, float_format="%.6f")

# Ablation: seberapa mudah kelas dipisahkan oleh subset fitur (diagnostik kualitas dataset)
abl = []
SETS = {"all_features": FEATS,
        "packets_only": ["packets"],
        "without_packets_bytes": [c for c in FEATS if c not in ("packets", "bytes")],
        "without_volume_and_ratio": [c for c in FEATS if c not in ("packets", "bytes", "mean_packet_size_B",
                                                                    "packets_per_second", "tcp_syn_ratio",
                                                                    "arp_request_reply_ratio")],
        "ports_and_protocol_only": ["src_port", "dst_port"] + ["proto_" + p for p in PROTOS]}
for name, cols in SETS.items():
    _, f, _, _, _ = evaluate("leave_one_repetition_out", cols)
    abl.append(dict(feature_set=name, n_features=len(cols), features=" ".join(cols), scheme="leave_one_repetition_out",
                    accuracy_mean=f.accuracy.mean(), accuracy_std=f.accuracy.std(ddof=1),
                    f1_macro_mean=f.f1_macro.mean(), f1_macro_std=f.f1_macro.std(ddof=1),
                    auc_ovr_macro_mean=f.auc_ovr_macro.mean(), total_errors=int(f.n_errors.sum())))
abl = pd.DataFrame(abl)
abl.to_csv(os.path.join(D4, "feature_ablation.csv"), index=False, float_format="%.6f")
print(abl.drop(columns="features").to_string())
open(os.path.join(D4, "environment.txt"), "w").write(
    f"python {platform.python_version()}\nscikit-learn {sklearn.__version__}\nnumpy {np.__version__}\n"
    f"pandas {pd.__version__}\nplatform {platform.platform()}\ncpu_count {os.cpu_count()}\nseed {SEED}\n"
    f"model RandomForestClassifier(n_estimators=200, default lainnya)\nfeatures {' '.join(FEATS)}\n")
