#!/usr/bin/env python3
"""
01_generate_pcap.py
Membangun PCAP SINTETIS dari flow record di netflow.csv.

Setiap flow record diekspansi menjadi paket mentah (Ethernet/IPv4/TCP|UDP|ICMP atau
Ethernet/ARP) sehingga, bila PCAP diagregasi kembali per flow, hasilnya sama dengan
netflow.csv untuk: 5-tuple, jumlah paket, jumlah byte, dan durasi.

PENTING: ini BUKAN hasil capture testbed. Paket dibangkitkan secara deterministik
(seed tetap) dari statistik flow. Payload adalah filler ber-tanda "SYNTHETIC".

Konvensi:
  - Flow bersifat unidirectional (seperti NetFlow v5): semua paket src -> dst.
  - bytes  = jumlah IP total length (Layer-3) untuk TCP/UDP/ICMP,
             jumlah panjang frame Ethernet untuk ARP (ARP bukan IP).
  - Timestamp PCAP resolusi nanodetik (magic 0xa1b23c4d).
  - Satu file PCAP per (scenario, repetition).
"""
import os, struct, hashlib, gzip
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, "1_netflow", "netflow.csv")
OUT_PCAP = os.path.join(ROOT, "2_pcap")
os.makedirs(OUT_PCAP, exist_ok=True)

SEED = 20261002
BASE_EPOCH_S = 1_700_000_000          # titik nol sintetis (bukan tanggal eksperimen)
GAP_S = 30                            # jeda antar capture
SCEN_ORDER = ["Benign", "Port_Scanning", "DDoS_SYN_Flood", "ARP_Spoofing"]
FILL = (b"SYNTHETIC-TRAFFIC-PAYLOAD-" * 80)[:2000]
BROADCAST = b"\xff" * 6
rng = np.random.default_rng(SEED)

F_FIN, F_SYN, F_RST, F_PSH, F_ACK = 0x01, 0x02, 0x04, 0x08, 0x10


def ip2b(ip):
    return bytes(int(x) for x in ip.split("."))


def mac_of(ip):
    """MAC 'asli' sebuah host: locally-administered, diturunkan dari IP."""
    return b"\x02\x00" + ip2b(ip)


def mac_str(m):
    return ":".join("%02x" % x for x in m)


def csum(b):
    if len(b) & 1:
        b += b"\x00"
    s = int(np.frombuffer(b, dtype=">u2").sum(dtype=np.uint64))
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return (~s) & 0xFFFF


def distribute(n, total, lo, hi, jit):
    """n bilangan bulat dalam [lo,hi] yang jumlahnya tepat = total."""
    base, rem = divmod(total, n)
    assert lo <= base and base + (1 if rem else 0) <= hi, (n, total, lo, hi)
    arr = np.full(n, base, dtype=np.int64)
    arr[:rem] += 1
    a = min(base - lo, hi - (base + 1), jit)
    h = a // 2 - 1
    if h >= 1 and n > 1:
        z = rng.integers(-h, h + 1, n)
        z -= int(round(z.mean()))
        s = int(z.sum())
        if s:
            idx = rng.choice(n, abs(s), replace=False)
            z[idx] -= np.sign(s)
        arr += z
    rng.shuffle(arr)
    assert arr.sum() == total and arr.min() >= lo and arr.max() <= hi
    return arr


def ipv4(src, dst, proto, ttl, ident, l4):
    tot = 20 + len(l4)
    h = struct.pack("!BBHHHBBH4s4s", 0x45, 0, tot, ident & 0xFFFF, 0x4000, ttl, proto, 0, src, dst)
    h = h[:10] + struct.pack("!H", csum(h)) + h[12:]
    return h + l4


def tcp_seg(src, dst, sport, dport, seq, ack, flags, win, opts, payload):
    doff = (20 + len(opts)) // 4
    h = struct.pack("!HHIIBBHHH", sport, dport, seq & 0xFFFFFFFF, ack & 0xFFFFFFFF, doff << 4, flags, win, 0, 0)
    seg = h + opts + payload
    pseudo = src + dst + struct.pack("!BBH", 0, 6, len(seg))
    c = csum(pseudo + seg)
    return seg[:16] + struct.pack("!H", c) + seg[18:]


def udp_dgram(src, dst, sport, dport, payload):
    ln = 8 + len(payload)
    h = struct.pack("!HHHH", sport, dport, ln, 0)
    c = csum(src + dst + struct.pack("!BBH", 0, 17, ln) + h + payload) or 0xFFFF
    return struct.pack("!HHHH", sport, dport, ln, c) + payload


def icmp_echo(ident, seq, payload):
    h = struct.pack("!BBHHH", 8, 0, 0, ident & 0xFFFF, seq & 0xFFFF)
    c = csum(h + payload)
    return struct.pack("!BBHHH", 8, 0, c, ident & 0xFFFF, seq & 0xFFFF) + payload


OPT_FULL = (b"\x02\x04\x05\xb4" + b"\x04\x02" + b"\x08\x0a" + b"\x00\x00\x10\x00" + b"\x00\x00\x00\x00"
            + b"\x01" + b"\x03\x03\x07")           # MSS, SACK-perm, TS, NOP, WScale = 20 B
OPT_MSS = b"\x02\x04\x05\xb4"                       # MSS saja = 4 B


def syn_opts(size):
    if size >= 60:
        return OPT_FULL
    if size >= 44:
        return OPT_MSS
    return b""


def build_flow(r, start_ns, attacker_mac):
    """Mengembalikan (list[(ts_ns, frame)], dict statistik turunan paket)."""
    n, total, proto, scen = int(r.packets), int(r.bytes), r.protocol, r.scenario
    dur_ns = int(round(r.duration_s * 1e9))
    if n > 2:
        mid = np.sort(rng.integers(1, max(dur_ns, 2), n - 2))
        offs = np.concatenate(([0], mid, [dur_ns]))
    else:
        offs = np.array([0, dur_ns][:n])
    ts = start_ns + offs
    src, dst = ip2b(r.src_ip), ip2b(r.dst_ip)
    smac, dmac = mac_of(r.src_ip), mac_of(r.dst_ip)
    st = dict(tcp_syn_count=0, tcp_ack_count=0, tcp_rst_count=0, tcp_fin_count=0, tcp_psh_count=0,
              tcp_flags_or=0, ttl_min=np.nan, ttl_max=np.nan, ttl_mean=np.nan,
              arp_request_count=0, arp_reply_count=0, src_mac=mac_str(smac), dst_mac=mac_str(dmac))
    frames = []

    if proto == "ARP":
        ratio = float(r.arp_request_reply_ratio)
        n_req = int(round(n * ratio / (1.0 + ratio)))
        n_req = min(max(n_req, 0), n)
        is_req = np.zeros(n, dtype=bool)
        is_req[rng.choice(n, n_req, replace=False)] = True
        sizes = distribute(n, total, 42, 1514, 8)
        for i in range(n):
            if is_req[i]:   # request sah dari pemilik IP: "who has dst? tell src"
                eth = BROADCAST + smac + b"\x08\x06"
                arp = struct.pack("!HHBBH6s4s6s4s", 1, 0x0800, 6, 4, 1, smac, src, b"\x00" * 6, dst)
            else:           # reply palsu: MAC penyerang mengklaim IP src ke korban dst
                eth = dmac + attacker_mac + b"\x08\x06"
                arp = struct.pack("!HHBBH6s4s6s4s", 1, 0x0800, 6, 4, 2, attacker_mac, src, dmac, dst)
            fr = eth + arp
            fr += b"\x00" * (int(sizes[i]) - len(fr))
            frames.append((int(ts[i]), fr))
        st["arp_request_count"], st["arp_reply_count"] = int(n_req), int(n - n_req)
        st["src_mac"] = mac_str(smac) + "|" + mac_str(attacker_mac)
        return frames, st

    eth = dmac + smac + b"\x08\x00"
    last = int(r.src_ip.split(".")[-1])
    if scen == "Port_Scanning":
        ttls = rng.integers(37, 60, n)            # nmap raw probe: TTL acak 37..59
    elif scen == "DDoS_SYN_Flood":
        ttls = np.full(n, 64)                     # hping3 default
    else:
        ttls = np.full(n, 128 if last % 3 == 0 else 64)   # "OS" host ditentukan dari IP
    st["ttl_min"], st["ttl_max"], st["ttl_mean"] = int(ttls.min()), int(ttls.max()), round(float(ttls.mean()), 3)
    ident0 = int(rng.integers(0, 65536))

    if proto == "TCP":
        n_syn = min(max(int(round(n * float(r.tcp_syn_ratio))), 0), n)
        syn = np.zeros(n, dtype=bool)
        if scen == "Benign":
            if n_syn:
                syn[0] = True
                if n_syn > 1:
                    syn[rng.choice(np.arange(1, n), n_syn - 1, replace=False)] = True
            n_oth = n - n_syn
            sizes = np.zeros(n, dtype=np.int64)
            syn_total = 60 * n_syn
            if n_oth and 40 * n_oth <= total - syn_total <= 1500 * n_oth:
                sizes[syn] = 60
                sizes[~syn] = distribute(n_oth, total - syn_total, 40, 1500, 800)
            else:
                sizes = distribute(n, total, 40, 1500, 0)
            win = 64240
        else:
            if n_syn:                                  # paket pertama flow serangan selalu SYN
                syn[0] = True
                if n_syn > 1:
                    syn[rng.choice(np.arange(1, n), n_syn - 1, replace=False)] = True
            sizes = distribute(n, total, 40, 1500, 8)
            win = 1024 if scen == "Port_Scanning" else 512
        isn = int(rng.integers(1, 2**32 - 1))
        peer = int(rng.integers(1, 2**32 - 1))
        seq = isn + 1
        nonsyn_idx = np.flatnonzero(~syn)
        last_nonsyn = int(nonsyn_idx[-1]) if len(nonsyn_idx) else -1
        for i in range(n):
            size = int(sizes[i])
            if syn[i]:
                opts = syn_opts(size)
                pl = FILL[: size - 40 - len(opts)]
                fl, sq, ak = F_SYN, isn, 0
            else:
                opts = b""
                pl = FILL[: size - 40]
                if scen == "Port_Scanning":
                    fl = F_RST
                elif scen == "DDoS_SYN_Flood":
                    fl = F_ACK
                elif i == last_nonsyn:
                    fl = F_FIN | F_ACK
                else:
                    fl = (F_PSH | F_ACK) if pl else F_ACK
                sq, ak = seq, (0 if fl == F_RST else peer)
                seq += len(pl)
            st["tcp_syn_count"] += bool(fl & F_SYN); st["tcp_ack_count"] += bool(fl & F_ACK)
            st["tcp_rst_count"] += bool(fl & F_RST); st["tcp_fin_count"] += bool(fl & F_FIN)
            st["tcp_psh_count"] += bool(fl & F_PSH); st["tcp_flags_or"] |= fl
            l4 = tcp_seg(src, dst, int(r.src_port), int(r.dst_port), sq, ak, fl, win, opts, pl)
            frames.append((int(ts[i]), eth + ipv4(src, dst, 6, int(ttls[i]), ident0 + i, l4)))
    elif proto == "UDP":
        sizes = distribute(n, total, 28, 1500, 400)
        for i in range(n):
            l4 = udp_dgram(src, dst, int(r.src_port), int(r.dst_port), FILL[: int(sizes[i]) - 28])
            frames.append((int(ts[i]), eth + ipv4(src, dst, 17, int(ttls[i]), ident0 + i, l4)))
    elif proto == "ICMP":
        # ICMP tidak punya port: src_port dipakai sebagai ICMP identifier agar flow bisa dilacak
        sizes = distribute(n, total, 28, 1500, 400)
        for i in range(n):
            l4 = icmp_echo(int(r.src_port), i, FILL[: int(sizes[i]) - 28])
            frames.append((int(ts[i]), eth + ipv4(src, dst, 1, int(ttls[i]), ident0 + i, l4)))
    else:
        raise ValueError(proto)
    for k in ("tcp_syn_count", "tcp_ack_count", "tcp_rst_count", "tcp_fin_count", "tcp_psh_count"):
        st[k] = int(st[k])
    return frames, st


def main():
    df = pd.read_csv(SRC)
    enr, manifest, pkt_rows = [], [], []
    t_cursor = BASE_EPOCH_S
    for rep in sorted(df.repetition.unique()):
        for scen in SCEN_ORDER:
            g = df[(df.scenario == scen) & (df.repetition == rep)]
            if g.empty:
                continue
            cap = int(g.capture_duration_s.iloc[0])
            cap_start_ns = t_cursor * 10**9
            onset = 0.0 if scen == "Benign" else float(rng.uniform(3.0, 10.0))
            attacker_mac = bytes([0x02, 0xAA, 0xAA, 0xAA, 0x00, int(rep)])
            hi = cap - g.duration_s.to_numpy() - 0.5
            starts = rng.uniform(onset, hi)
            if scen != "Benign":
                starts[int(rng.integers(0, len(starts)))] = onset    # flow serangan pertama tepat di onset
            fname = f"{scen.lower()}_rep{rep}.pcap"
            allf = []
            for (_, r), s in zip(g.iterrows(), starts):
                start_ns = cap_start_ns + int(round(s * 1e9))
                frames, st = build_flow(r, start_ns, attacker_mac)
                end_ns = frames[-1][0]
                allf.extend((t, f, int(r.flow_id)) for t, f in frames)
                enr.append(dict(flow_id=int(r.flow_id), capture_id=f"{scen}_rep{rep}", pcap_file=fname,
                                capture_start_epoch_s=t_cursor,
                                flow_start_rel_s=round((start_ns - cap_start_ns) / 1e9, 9),
                                flow_end_rel_s=round((end_ns - cap_start_ns) / 1e9, 9),
                                flow_start_epoch_ns=start_ns, flow_end_epoch_ns=end_ns, **st))
            allf.sort(key=lambda x: x[0])
            path = os.path.join(OUT_PCAP, fname)
            h = hashlib.sha256()
            with open(path, "wb") as fo:
                gh = struct.pack("<IHHiIII", 0xA1B23C4D, 2, 4, 0, 0, 65535, 1)
                fo.write(gh); h.update(gh)
                for no, (t, f, fid) in enumerate(allf, 1):
                    rec = struct.pack("<IIII", t // 10**9, t % 10**9, len(f), len(f)) + f
                    fo.write(rec); h.update(rec)
                    pkt_rows.append((fname, no, t, fid, int(g.label.iloc[0]), len(f)))
            manifest.append(dict(pcap_file=fname, scenario=scen, repetition=int(rep), label=int(g.label.iloc[0]),
                                 capture_start_epoch_s=t_cursor, capture_duration_s=cap,
                                 attack_onset_rel_s=(np.nan if scen == "Benign" else round(onset, 9)),
                                 flows=len(g), packets=len(allf),
                                 file_bytes=os.path.getsize(path),
                                 attacker_mac=(mac_str(attacker_mac) if scen == "ARP_Spoofing" else ""),
                                 sha256=h.hexdigest(), data_status="synthetic"))
            print(f"{fname:32s} flows={len(g):5d} packets={len(allf):7d} size={os.path.getsize(path)/1e6:7.2f} MB")
            t_cursor += cap + GAP_S

    enr = pd.DataFrame(enr)
    out = df.drop(columns=["data_status"]).merge(enr, on="flow_id", how="left", validate="1:1")
    hexflags = out.tcp_flags_or.map(lambda v: "0x%02x" % int(v))
    out["tcp_flags_or"] = hexflags
    out["data_status"] = "synthetic"
    out.to_csv(os.path.join(ROOT, "1_netflow", "netflow_enriched.csv"), index=False)
    pd.DataFrame(manifest).to_csv(os.path.join(OUT_PCAP, "pcap_manifest.csv"), index=False)
    pk = pd.DataFrame(pkt_rows, columns=["pcap_file", "packet_no", "ts_epoch_ns", "flow_id", "label", "frame_len"])
    with gzip.open(os.path.join(OUT_PCAP, "packet_ground_truth.csv.gz"), "wt") as fo:
        pk.to_csv(fo, index=False)
    print("total packets", len(pk))


if __name__ == "__main__":
    main()
